'use client'
import React from 'react'

export default function RecordingsList() {
  return (
    <div>
      <h1>Recordings</h1>
      {/* Add your recordings list implementation here */}
    </div>
  )
} 
import React from 'react'

export function ActionHeader() {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      {/* Add your action header content here */}
    </header>
  )
} 
import React from 'react'
import VideoPlayer from "../components/features/VideoPlayer"
import AIAssistant from "../components/features/AIAssistant"

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          <h1 className="text-2xl font-bold mb-4">
            Introduction to Machine Learning
          </h1>
          <p className="text-gray-600 mb-4">
            April 27 2023 9:51 AM - 9:56 AM
          </p>
          <VideoPlayer />
          
          <div className="mt-8">
            <div className="border-b">
              <nav className="flex space-x-8">
                {["HIGHLIGHTS", "KEY POINTS", "TRANSCRIPTS", "SUMMARY", "SLIDES", "NOTES"].map(
                  (tab) => (
                    <button
                      key={tab}
                      className="px-4 py-2 text-gray-600 hover:text-gray-900 border-b-2 border-transparent hover:border-[#7B68EE]"
                    >
                      {tab}
                    </button>
                  )
                )}
              </nav>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-4">
          <AIAssistant />
        </div>
      </div>
    </div>
  )
} 
import React from 'react'

export function Notifications() {
  return (
    <div className="fixed top-4 right-4 z-50">
      {/* Add your notifications content here */}
      <div className="notifications-container">
      </div>
    </div>
  )
} 
import React from 'react'

export function UserMenu() {
  return (
    <div className="relative">
      {/* Add your user menu content here */}
      <div className="p-2">
        <button className="text-gray-700 hover:text-gray-900">
          User Menu
        </button>
      </div>
    </div>
  )
} 